class PostsController < ApplicationController
  

  def index
  end

  def show
  end


end
